

# IDEE PER LE PROSSIME VERSIONI:

- 1.5
(Cancella le immagini originali (DELETE ORIGINAL), Aggiungi l'immagine ridimensionata)
(Cancella le immagini ridimensionate)
Oppure un
Esistono due versioni dell'immagine, una può essere già ridimensionata quindi bisogna aggiungere la possibilità di creare i resize mantenendo le immagini originali, ed eliminarle in un secondo momento

elimina il limite < 400px


Non deve tentare di fare il resize delle immagini in CDN

-----------------------------



- resize: min-width min-height valori minimi del resize che non devono essere superati
- Una volta aggiunto min-width e min-height posso avvertire se ci sono immagini sotto quelle dimensioni.
- Esportazione csv per excel dei dati convertiti (o delle immagini più piccole di... o delle immagini più grandi di...)



- CONVERTI FORMATI!

- resize delle thumbs

- Test sulla conversione
- filtra i tipi di dati da escludere nel resize (post_type, o non collegato)
- permetti di ordinare i media per filesize




# VALIDAZIONE
*Descrizione su come testare il lavoro o/e l'elenco delle operazioni fatte per documentare che il codice funziona*
## Test
## Log


# NOTE
https://developer.wordpress.org/plugins/plugin-basics/
https://developer.wordpress.org/coding-standards/wordpress-coding-standards/



PLUGIN STRUTTURA
https://github.com/DevinVinson/WordPress-Plugin-Boilerplate/blob/master/plugin-name/plugin-name.php


https://wordpress.org/plugins/developers/